/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package QuickChatApplication;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author user
 */
public class MessageTest {
    
    private Message message1;
    private Message message2;
    
    @BeforeEach
    public void setUp(){
        message1 = new Message(1);
        message2 = new Message(2);
    }
@Test
    public void testMessageLengthSuccess() {
        String validMessage = "Hi Mike, can you join us for dinner tonight?";
        assertTrue(validMessage.length() <= 250, "Message ready to send.");
    }
 
    @Test
    public void testMessageLengthFailure() {
        String longMessage = "A".repeat(251);
        int excess = longMessage.length() - 250;
        assertFalse(longMessage.length() <= 250,
                "Message exceeds 250 characters by " + excess + "; please reduce the size.");
    }
 
    
 
    @Test
    public void testRecipientCellSuccess() {
        String result = message1.checkRecipientCell("+27718693002");
        assertEquals("Cell phone number successfully captured.", result);
    }
 
    @Test
    public void testRecipientCellFailure() {
        String result = message2.checkRecipientCell("08575975889");
        assertEquals(
            "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.",
            result
        );
    }

 
    @Test
    public void testMessageHashMessage1() {
        message1.setMessageText("Hi Mike, can you join us for dinner tonight?");
        String hash = message1.createMessageHash();
 
        assertNotNull(hash);
        assertEquals(hash.toUpperCase(), hash, "Hash should be in all caps");
        assertTrue(hash.contains(":1:"), "Hash should contain the message number");
        assertTrue(hash.endsWith("HITONIGHT?"), "Hash should end with HITONIGHT?");
    }
 
    @Test
    public void testMessageHashMessage2() {
        message2.setMessageText("Hi Keegan, did you receive the payment?");
        String hash = message2.createMessageHash();
 
        assertNotNull(hash);
        assertEquals(hash.toUpperCase(), hash, "Hash should be in all caps");
        assertTrue(hash.contains(":2:"), "Hash should contain the message number");
        assertTrue(hash.endsWith("HIPAYMENT?"), "Hash should end with HIPAYMENT?");
    }
 
    
 
    @Test
    public void testMessageIDCreated() {
        String id = message1.getMessageID();
        assertNotNull(id, "Message ID generated: " + id);
        assertTrue(message1.checkMessageID(), "Message ID generated: " + id);
        assertEquals(10, id.length(), "Message ID should be 10 characters");
    }
 
   
 
    @Test
    public void testSentMessageSend() {
        message1.setMessageText("Hi Mike, can you join us for dinner tonight?");
        message1.checkRecipientCell("+27718693002");
        message1.createMessageHash();
        assertEquals("Message successfully sent.", message1.sentMessage(0));
    }
 
    @Test
    public void testSentMessageDisregard() {
        assertEquals("Press 0 to delete the message", message1.sentMessage(1));
    }
 
    @Test
    public void testSentMessageStore() {
        message1.setMessageText("Hi Mike, can you join us for dinner tonight?");
        message1.checkRecipientCell("+27718693002");
        message1.createMessageHash();
        assertEquals("Message successfully stored.", message1.sentMessage(2));
    }
}    

