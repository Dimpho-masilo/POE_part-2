/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package QuickChatApplication;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author user
 */
public class QuickChatApplicationIT {
    
    public QuickChatApplicationIT() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    @Test
    public void testSendMessages() {
    }

    @Test
    public void testGenerateMessageID() {
    }

    @Test
    public void testGenerateMessageHash() {
    }

    @Test
    public void testDisplayMessageDetails() {
    }
    
}
