/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QuickChatApplication;


/**
 *
 * @author user
 */
public class Login {
    // Stored registration information
    private String fNameValue;
    private String lNameValue;
    private String uNameValue;
    private String pWordValue;
    private String phoneValue;

    /**
     * Constructor initializes Login with user data.
     * 
     * @param fNameValue First name
     * @param lNameValue Last name
     * @param uNameValue Username
     * @param pWordValue Password
     * @param phoneValue Cell phone number
     */
    public Login(String fNameValue, String lNameValue, String uNameValue, String pWordValue, String phoneValue) {
        this.fNameValue = fNameValue;
        this.lNameValue = lNameValue;
        this.uNameValue = uNameValue;
        this.pWordValue = pWordValue;
        this.phoneValue = phoneValue;
    }

    /**
     * Validates username format.
     * Must contain underscore (_) and be 5 characters or less.
     * 
     * @return true if valid
     */
    public boolean checkUserName() {
        return uNameValue.contains("_") && uNameValue.length() <= 5;
    }

    /**
     * Validates password complexity.
     * Must have: 8+ chars, uppercase, digit, special character.
     * 
     * @return true if valid
     */
    public boolean checkPasswordComplexity() {
        boolean hasUpperChar = false;
        boolean hasDigitChar = false;
        boolean hasSpecialChar = false;

        if (pWordValue.length() < 8) {
            return false;
        }

        for (int idx = 0; idx < pWordValue.length(); idx++) {
            char c = pWordValue.charAt(idx);
            
            if (Character.isUpperCase(c)) hasUpperChar = true;
            if (Character.isDigit(c)) hasDigitChar = true;
            if (!Character.isLetterOrDigit(c)) hasSpecialChar = true;
        }

        return hasUpperChar && hasDigitChar && hasSpecialChar;
    }

    /**
     * Validates South African cell phone number.
     * Format: +27 followed by exactly 9 digits.
     * 
     * @return true if valid
     */
    public boolean checkCellPhoneNumber() {
        return phoneValue.matches("^\\+27\\d{9}$");
    }

    /**
     * Processes registration and returns result message.
     * 
     * @return Registration message
     */
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        
        if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        
        if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        
        return "Username successfully captured.\nPassword successfully captured.\nCell phone number successfully added.";
    }

    /**
     * Authenticates user login.
     * 
     * @param enteredUser Username entered
     * @param enteredPass Password entered
     * @return true if authenticated
     */
    public boolean loginUser(String enteredUser, String enteredPass) {
        return uNameValue.equals(enteredUser) && pWordValue.equals(enteredPass);
    }

    /**
     * Returns login status message.
     * 
     * @param enteredUser Username entered
     * @param enteredPass Password entered
     * @return Status message
     */
    public String returnLoginStatus(String enteredUser, String enteredPass) {
        if (loginUser(enteredUser, enteredPass)) {
            return "Welcome " + fNameValue + ", " + lNameValue + " it is great to see you again.";
        }
        return "Username or password incorrect, please try again.";
    }
}

    
