/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package QuickChatApplication;

import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;


public class Message {
    private String messageID;
    private String recipient;
    private String messageText;
    private String messageHash;
    private int messageNumber;

    static int totalMessagesSent = 0;
    static ArrayList<String> messageList = new ArrayList<>();    

 public Message(String messageID, String recipient, String messageText, int messageNumber) {
        this.messageID     = messageID;
        this.recipient     = recipient;
        this.messageText   = messageText;
        this.messageNumber = messageNumber;
        this.messageHash   = createMessageHash();
 }       
public boolean checkMessageID() { // method located inside  
        return messageID.length() == 10;     
}
public Message (int messageNumber){
this. messageNumber = messageNumber;
this.messageID      = String.format("%010d", new Random().nextInt(1_000_000_000));

}

public String checkRecipientCell(String Cell) {
        if (recipient.matches("^0[6-8]\\d{8}$")) {
            return "Cell phone number successfully captured.";
        } else {
            return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
        }
    }
public String createMessageHash() {
        String[] words = messageText.trim().split(" ");
        String first = words[0];
        String last  = words[words.length - 1];
        return (messageID.substring(0, 2) + ":" + messageNumber + ":" + first + last).toUpperCase();
    }
public String sentMessage(int action) {
        switch (action) {
            case 0 -> {
                totalMessagesSent++;
                messageList.add(printMessages());
                return "Message successfully sent.";
            }
            case 1 -> {
                return "Press 0 to delete the message";
            }
            case 2 -> {
                storeMessage();
                return "Message successfully stored.";
            }
            default -> {
                return "No action taken.";
            }
        }
    }

    // Message printer
    public String printMessages() {
        return "Message ID: "  + messageID   + "\n" +
               "Hash: "        + messageHash + "\n" +
               "Recipient: "   + recipient   + "\n" +
               "Message: "     + messageText;
    }

    // ── RETURN TOTAL MESSAGES ─────────────────────────────────────────────────
    public int returnTotalMessages() {
        return totalMessagesSent;
    }

    // ── STORE MESSAGE ─────────────────────────────────────────────────────────
    public void storeMessage() {
        StringBuilder jsonEntry = new StringBuilder();
        jsonEntry.append("{\n");
        jsonEntry.append("  \"MessageID\": \"").append(messageID).append("\",\n");
        jsonEntry.append("  \"MessageHash\": \"").append(messageHash).append("\",\n");
        jsonEntry.append("  \"Recipient\": \"").append(recipient).append("\",\n");
        jsonEntry.append("  \"Message\": \"").append(messageText.replace("\"", "\\\"")).append("\"\n");
        jsonEntry.append("},\n");

        try (FileWriter file = new FileWriter("messages.json", true)) {
            file.write(jsonEntry.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing to file: " + e.getMessage());
        }
    }

    // ── GETTERS ───────────────────────────────────────────────────────────────
    public String getMessageID()   { return messageID; }
    public String getRecipient()   { return recipient; }
    public String getMessageText() { return messageText; }
    public String getMessageHash() { return messageHash; }
  
    public void setMessageText(String messageText) { this.messageText = messageText; }
    public void setRecipient(String recipient)     { this.recipient = recipient; }
}

